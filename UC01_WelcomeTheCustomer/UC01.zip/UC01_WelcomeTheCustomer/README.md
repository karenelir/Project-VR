# UC01 - Welcome the Customer

Choregraphe project for Pepper, built the same way as `UC02_ChooseGame` and `UC05_CelebrateWithTheUser`
(Say boxes, a qichat dialog box, Python "Show Web View" boxes, tablet pages sending taps back as
ALMemory events through the course template's `html/js/qievents.js`).
Open `UC01_WelcomeTheCustomer.pml` in Choregraphe.

## Flow (behavior_1)

| Use case | Box(es) | Tablet page |
|---|---|---|
| PRECOND-1 - idle in reception | Init (stand, basic awareness on) | `welcome.html` (attract screen) |
| Step 1 - detect a customer | Wait For Customer (step 1) | `welcome.html` switches to "Hello!" |
| Step 2 - welcome + introduce itself | Welcome (step 2), with a wave | - |
| Step 3 - first time? | Ask First Time (step 3) | `visitor.html` (Yes / No buttons) |
| 3a / 3a1 - group | Welcome Group (3a) → Ask Group (3a1) | `visitor.html`, group version with "Some of us" |
| Step 4 / 3a2 - answer | visitor_d → Save Visitor Status | - |
| 4a - answer not recognized | visitor_d `e:Dialog/NotUnderstood` → asks again + highlights the buttons | `visitor.html?hint=1` |
| 5a - new customer | New Customer Intro (5a) | `newvisitor.html` |
| 5b - returning customer | Welcome Back (5b) | `welcomeback.html` |
| Open issue - conflicting group answers | Mixed Group Welcome → New Customer Intro | `newvisitor.html?mixed=1` |

## Detection (Wait For Customer box)

- **Real robot**: waits for "Tap to start" on the welcome screen (nothing starts before the tap),
  then counts the people in zones 1 and 2. 2 or more people means a group (extension 3a).
- **Optional**: set `Also start when someone walks up` on the box to also start on
  `EngagementZones/PersonEnteredZone1`, `PersonEnteredZone2` or `PersonApproached` (off by default).
- **Virtual robot** (no tablet, so nobody can tap): detection is simulated after 3 seconds.
  `Simulated people count` sets the group size used in the simulation.
  `Simulate detection after (s)` > 0 forces simulation on the real robot too.

## Postconditions

- **POSTCOND-1**: the visitor status is stored in ALMemory `UC01/VisitorStatus` (`new`, `returning` or `mixed`)
  together with `UC01/GroupSize`, so the next use case can read it.
- **POSTCOND-2**: both endings finish with "let's get you checked in" and the behavior ends (next: UC-02 Check In).

## Open issue: groups with conflicting answers

If the group answers "some of us" (by voice or with the third button), Pepper welcomes back the regulars,
welcomes the first-timers, and then gives the full introduction so nobody is left out.

## Testing on the virtual robot

Press Play, wait 3 seconds for the simulated detection, then type in the Dialog panel:
`yes` (5a), `no` (5b), `some of us` (mixed group), or something random like `banana` (extension 4a).

## Speech smoothness (v1.3)

- Say boxes: speed 90 %, no extra random gestures on top of an explicit `^start` animation,
  no `^wait` in the middle of a sentence (Pepper used to freeze until the wave finished).
- Basic awareness tracks with the head only and locks onto the customer once they tap,
  so Pepper doesn't turn or jump between people while talking.
- Tablet pages no longer call `cleanWebview()` before each page (white flash + reload during speech).
- The Yes / No page appears while Pepper asks the question, not after.

## Group only (v1.4)

Customers always come as a group, so the single-customer path was removed
("Welcome (step 2)" and "Ask First Time (step 3)" boxes). After the tap Pepper always says
"Hello everyone", asks "Is this your first time here? Yes, no, or some of us", and the tablet always
shows the three buttons. `UC01/GroupSize` is still stored (at least 2).

## Tablet black screen fix (v1.5)

`newvisitor.html` went black about 1 s after it appeared. Pepper's old tablet browser can fail to draw a page
that combines a full-screen CSS blur with several animated clip-path cards. The backdrop no longer uses
`filter: blur()` (it is just dimmed), and the cards fade in without clip-path or transform.

## Behavior ended right after the answer (v1.6)

The qichat rules set `$visitorStatus` and `$onStopped=1` together. Save Visitor Status routed immediately,
so the intro Say box started while the dialog box was still stopping; ALDialog then stopped that speech,
the Say box ended at once, the behavior finished and the tablet went black.
Now Save Visitor Status only stores the answer on `onStart`, and routes on a new input `onDialogStopped`
(linked from visitor_d `onStopped`), 0.5 s after the dialog has shut down.

## Tablet Yes / No taps ignored (v1.7)

The Yes / No page appears while Pepper is still asking, before visitor_d listens. A tap in that moment was
lost, and the page then locked its buttons. `uc01Choose(..., true)` now resends the event every 2 s
(up to 30 s) until Pepper changes the page; ALDialog takes the first one it receives.
